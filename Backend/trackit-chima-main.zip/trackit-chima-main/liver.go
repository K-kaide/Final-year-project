package main

// import (
// 	"fmt"
// 	"time"
// )

// const (
// 	DDMMYYYYhhmmss = "01/02/2006 15:04:05"
// 	DDMMYYYY       = "01/02/2006"
// 	hhmm           = "16:04"
// )

// func main() {
// 	date := time.Now().UTC()
// 	value := fmt.Sprint(date.Hour() + 1) + ":" + fmt.Sprint(date.Minute())
// 	fmt.Println(value)
// 	fmt.Println(date.Format(DDMMYYYYhhmmss))
// 	fmt.Println(date.Format(DDMMYYYY))
// 	fmt.Println(date.Format(hhmm))
// }
