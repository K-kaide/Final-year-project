# TRACKIT APPLICATION BACKEND IN GOLANG
To run:
1. Install go from go.dev
2. Make sure you have internet connection and run: go get -u
3. Finally run: go run main.go
